package gestaoImobiliaria;

public class Apartamento extends Imovel{
    private int andar;
    private int numero;
    private double condominio;
    private double fundoReserva;
    private double investimentos;
    public double calcularAluguel(){
        return -1;
    }
}
