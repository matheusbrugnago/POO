package gestaoImobiliaria;

public class Locatario extends Pessoa {
    private String email;
    private String salario;
}
