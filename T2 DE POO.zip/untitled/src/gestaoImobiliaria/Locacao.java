package gestaoImobiliaria;

import javax.xml.crypto.Data;
import java.util.Date;

public class Locacao {
    private Date dataInicio;
    private Data dataTermino;
    private Data dataPagamento;
    private Proprietario proprietario;
    private Corretor corretor;
    private Imovel imovel;
    public void enviarCobranca(){

    }
    public void pagarProprietario(){
    }
}
