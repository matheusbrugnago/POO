package gestaoImobiliaria;

public class Proprietario extends Pessoa implements ReceberValor{
    private String conta;
    private String agencia;
    @Override
    public void receber(double valor) {

    }
}
