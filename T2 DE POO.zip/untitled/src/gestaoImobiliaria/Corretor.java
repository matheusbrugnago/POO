package gestaoImobiliaria;

import java.util.Date;

public class Corretor extends Pessoa implements ReceberValor{
    private String registro;
    private Date dataAdmissao;
    private double comissao;
    private double totalComissaoAcumulada;
    public void sacarComissoes( double valor){

    }
    public void receber(double valor) {

    }
}

