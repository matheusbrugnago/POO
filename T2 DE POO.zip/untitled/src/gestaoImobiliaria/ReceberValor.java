package gestaoImobiliaria;

interface ReceberValor {
    public void receber(double valor);
}
