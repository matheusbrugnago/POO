package gestaoImobiliaria;

public class Casa extends Imovel{
    private int qtadeAndares;
    public double calcularAluguel(){
        return -1;
    }
}
