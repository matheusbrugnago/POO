package gestaoImobiliaria;

abstract class Pessoa {
    private String nome;
    private String telefone;
    private String endereco;
    private String cpf;
}
